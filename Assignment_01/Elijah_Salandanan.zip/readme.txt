
designed to take file input names in as arguments see below for example of how to run
with file inputs.
first file is the matrix input
second file is the word input

make Elijah_Salandanan
./Elijah_Salandanan in1_2.txt in2.txt